﻿using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel.DataAnnotations;

namespace InventoryAPI.Inventory.Models
{
    [BsonIgnoreExtraElements]
    public class Inventy
    {
        [Key]
        [BsonId]
        public int id { get; set; }
        [BsonElement("tagNumber")]
        public string? tagNumber { get; set; }
        [BsonElement("datePurchased")]
        public DateOnly? datePurchased { get; set; }
        [BsonElement("department")]
        public string? department { get; set; }
        [BsonElement("assignedTo")]
        public string? assignedTo { get; set; }
        [BsonElement("type")]
        public string? type { get; set; }
        [BsonElement("brandId")]
        public int? brandId { get; set; }

        [BsonElement("created_at")]
        public DateTime? created_at { get; set; }
        [BsonElement("updated_at")]
        public DateTime? updated_at { get; set; }
    }
}
