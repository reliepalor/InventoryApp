﻿using InventoryAPI.Inventory.Models;
namespace InventoryAPI.Inventory.Interfaces
{
    public interface IInventy<T> where T : class
    {
        Task<int> CreateInventy(Inventy inventy);
        Task<int> UpdateInventy(T inventy);
        Task<int> DeleteInventy(int inventyId);
        Task<IEnumerable<T>> GetAllInventory();
        Task<T?> GetInventoryById(int inventyId);
    }
}
