﻿using InventoryAPI.Inventory.Interfaces;
using InventoryAPI.Maintenance.Brand.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using InventoryModel = InventoryAPI.Inventory.Models.Inventy;

namespace InventoryAPI.Inventory.Controller.Inventy
{
    [Route("api/[controller]")]
    [ApiController]
    public class InventyController : ControllerBase
    {
        private readonly IInventy<InventoryModel> _inventyService;
        public InventyController(IInventy<InventoryModel> inventyService)
        {
            _inventyService = inventyService;
        }
        [HttpGet("GetAllInventory")]
        public async Task<ActionResult> GetAllInventory()
        {
            try
            {
                var inventy = await _inventyService.GetAllInventory();
                return Ok(inventy);
            }
            catch (Exception ex)
            {
                string message = "No inventory found.";
                return StatusCode(500, message);
            }
        }
        [HttpGet("GetInventoryById/{id}")]
        public async Task<ActionResult> GetInventoryById(int id)
        {
            try
            {
                var inventy = await _inventyService.GetInventoryById(id);
                if (inventy == null)
                {
                    return NotFound("Inventory not found.");
                }
                return Ok(inventy);
            }
            catch (Exception ex)
            {
                string message = "Error retrieving inventory.";
                return StatusCode(500, message);
            }
        }

        [HttpPost("createInventory")]
        public async Task<ActionResult> CreateInventy([FromBody] InventoryModel inventy)
        {
            var affected = await _inventyService.CreateInventy(inventy);
            if (affected > 0)
            {
                string Message = "Inventory successfully created.";
                return Ok(Message);
            }
            return StatusCode(500, "Insert failed");
        }
        [HttpPut("updateInventory/{id}")]
        public async Task<ActionResult> UpdateInventy(int id, [FromBody] InventoryModel inventy)
        {
            inventy.id = id;
            var affected = await _inventyService.UpdateInventy(inventy);
            if (affected > 0)
            {
                string Message = "Inventory successfully updated.";
                return Ok(Message);
            }
            return StatusCode(500, "Update failed");
        }
        [HttpDelete("deleteInventory/{id}")]
        public async Task<ActionResult> DeleteInventy(int id)
        {
            var affected = await _inventyService.DeleteInventy(id);
            if (affected > 0)
            {
                string Message = "Inventory successfully deleted.";
                return Ok(Message);
            }
            return StatusCode(500, "Delete failed");
        }
    }
}
