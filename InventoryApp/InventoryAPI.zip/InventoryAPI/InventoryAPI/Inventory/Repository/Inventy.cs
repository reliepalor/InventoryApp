﻿using InventoryAPI.Inventory.Interfaces;
using InventoryAPI.Inventory.Models;
using Microsoft.Data.SqlClient;
using System.Data;
using InventoryModel = InventoryAPI.Inventory.Models.Inventy;

namespace InventoryAPI.Inventory.Repository
{
    public class Inventy : IInventy<InventoryModel>
    {
        private readonly SqlConnection _sqlConnection;
        public Inventy(SqlConnection sqlConnection)
        {
            _sqlConnection = sqlConnection;
        }

        private async Task EnsureInventoryTableAsync()
        {
            const string ddl = @"IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Inventory]') AND type IN (N'U'))
                            BEGIN
                                CREATE TABLE [dbo].[Inventory] (
                                    [id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                                    [tagNumber] NVARCHAR(100) NULL,
                                    [datePurchased] DATETIME NULL,
                                    [department] NVARCHAR(100) NULL,
                                    [assignedTo] NVARCHAR(100) NULL,
                                    [type] NVARCHAR(100) NULL,
                                    [brandId] INT NULL,
                                    [created_at] DATETIME NULL,
                                    [updated_at] DATETIME NULL
                                );
                            END";
            using var cmd = new SqlCommand(ddl, _sqlConnection);
            if (_sqlConnection.State != ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }
            await cmd.ExecuteNonQueryAsync();
        }

        public async Task<int> CreateInventy(InventoryModel inventy)
        {
            await EnsureInventoryTableAsync();

            var now = DateTime.UtcNow;
            inventy.created_at = inventy.created_at == default ? now : inventy.created_at;
            inventy.updated_at = now;
            const string sql = @"INSERT INTO [dbo].[Inventory] (tagNumber, datePurchased, department, assignedTo, type, brandId, created_at, updated_at)
                                 VALUES (@tagNumber, @datePurchased, @department, @assignedTo, @type, @brandId, @created_at, @updated_at);";
            using var cmd = new SqlCommand(sql, _sqlConnection);
            cmd.Parameters.AddWithValue("@tagNumber", inventy.tagNumber ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@datePurchased", inventy.datePurchased.HasValue ? inventy.datePurchased.Value : DBNull.Value);
            cmd.Parameters.AddWithValue("@department", inventy.department ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@assignedTo", inventy.assignedTo ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@type", inventy.type ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@brandId", inventy.brandId.HasValue ? inventy.brandId.Value : DBNull.Value);
            cmd.Parameters.AddWithValue("@created_at", inventy.created_at);
            cmd.Parameters.AddWithValue("@updated_at", inventy.updated_at);
            if (_sqlConnection.State != System.Data.ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }
            var affected = await cmd.ExecuteNonQueryAsync();
            return affected;
        }

        public async Task<int> UpdateInventy(InventoryModel inventy)
        {
            await EnsureInventoryTableAsync();

            inventy.updated_at = DateTime.UtcNow;
            const string sql = @"UPDATE [dbo].[Inventory] 
                                 SET tagNumber = @tagNumber, 
                                     datePurchased = @datePurchased, 
                                     department = @department, 
                                     assignedTo = @assignedTo, 
                                     type = @type, 
                                     brandId = @brandId, 
                                     updated_at = @updated_at
                                 WHERE id = @id;";
            using var cmd = new SqlCommand(sql, _sqlConnection);
            cmd.Parameters.AddWithValue("@id", inventy.id);
            cmd.Parameters.AddWithValue("@tagNumber", inventy.tagNumber ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@datePurchased", inventy.datePurchased.HasValue ? inventy.datePurchased.Value : DBNull.Value);
            cmd.Parameters.AddWithValue("@department", inventy.department ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@assignedTo", inventy.assignedTo ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@type", inventy.type ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@brandId", inventy.brandId.HasValue ? inventy.brandId.Value : DBNull.Value);
            cmd.Parameters.AddWithValue("@updated_at", inventy.updated_at);
            if (_sqlConnection.State != ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }
            var affected = await cmd.ExecuteNonQueryAsync();
            return affected;
        }

        public async Task<int> DeleteInventy(int inventyId)
        {
            await EnsureInventoryTableAsync();

            const string sql = @"DELETE FROM [dbo].[Inventory] WHERE id = @id;";
            using var cmd = new SqlCommand(sql, _sqlConnection);
            cmd.Parameters.AddWithValue("@id", inventyId);
            if (_sqlConnection.State != ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }
            var deleted = await cmd.ExecuteNonQueryAsync();
            return deleted;
        }

        public async Task<IEnumerable<InventoryModel>> GetAllInventory()
        {
            await EnsureInventoryTableAsync();

            const string sql = @"SELECT id, tagNumber, datePurchased, department, assignedTo, type, brandId, created_at, updated_at 
                                 FROM [dbo].[Inventory];";
            using var cmd = new SqlCommand(sql, _sqlConnection);
            if (_sqlConnection.State != ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }
            var inventoryList = new List<InventoryModel>();
            using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                inventoryList.Add(MapReaderToInventory(reader));
            }
            return inventoryList;
        }

        public async Task<InventoryModel?> GetInventoryById(int inventyId)
        {
            await EnsureInventoryTableAsync();

            const string sql = @"SELECT id, tagNumber, datePurchased, department, assignedTo, type, brandId, created_at, updated_at 
                                 FROM [dbo].[Inventory] WHERE id = @id;";
            using var cmd = new SqlCommand(sql, _sqlConnection);
            cmd.Parameters.AddWithValue("@id", inventyId);
            if (_sqlConnection.State != ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }
            using var reader = await cmd.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return MapReaderToInventory(reader);
            }
            return null;
        }

        private static InventoryModel MapReaderToInventory(SqlDataReader reader)
        {
            return new InventoryModel
            {
                id = reader.GetInt32(reader.GetOrdinal("id")),
                tagNumber = reader.IsDBNull(reader.GetOrdinal("tagNumber")) ? null : reader.GetString(reader.GetOrdinal("tagNumber")),
                datePurchased = reader.IsDBNull(reader.GetOrdinal("datePurchased")) ? null : DateOnly.FromDateTime(reader.GetDateTime(reader.GetOrdinal("datePurchased"))),
                department = reader.IsDBNull(reader.GetOrdinal("department")) ? null : reader.GetString(reader.GetOrdinal("department")),
                assignedTo = reader.IsDBNull(reader.GetOrdinal("assignedTo")) ? null : reader.GetString(reader.GetOrdinal("assignedTo")),
                type = reader.IsDBNull(reader.GetOrdinal("type")) ? null : reader.GetString(reader.GetOrdinal("type")),
                brandId = reader.IsDBNull(reader.GetOrdinal("brandId")) ? null : reader.GetInt32(reader.GetOrdinal("brandId")),
                created_at = reader.IsDBNull(reader.GetOrdinal("created_at")) ? null : reader.GetDateTime(reader.GetOrdinal("created_at")),
                updated_at = reader.IsDBNull(reader.GetOrdinal("updated_at")) ? null : reader.GetDateTime(reader.GetOrdinal("updated_at"))
            };
        }
    }
}
