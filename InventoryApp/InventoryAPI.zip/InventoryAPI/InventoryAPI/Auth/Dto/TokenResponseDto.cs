﻿namespace CRUDApi.Auth.Dto
{
    public class TokenResponseDto
    {
        public required string Token { get; set; }
    }
}
