﻿namespace InventoryAPI.Auth.Models
{
    public class ssmsDBSettings
    {
        public string ssmsConnectionString { get; set; } = string.Empty;
    }
}
